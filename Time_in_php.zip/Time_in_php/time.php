<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    p {
        font-family: Digital-7;
        text-align: center;
        font-size: 60px;
        margin-top: 0px;
        font-style: italic;
    }
    h1{
        text-align: center;        
        font-family: Algerian;
    }
        
    </style>
</head>

<body>
   <h1>Ramadan is in</h1>
    <p id="demo">Welcome</p>
    <script>
    var countDownDate = <?php echo strtotime('Dec 15, 2020 4:0:0') ?> * 1000;
    var now = <?php echo time() ?> * 1000;
    var x = setInterval(function() {
        now = now + 1000;
        var distance = countDownDate - now;
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        document.getElementById("demo").innerHTML = days + ": " + hours + ": " +
            minutes + ": " + seconds + " ";
        if (distance < 0) {
            clearInterval(x);
            document.getElementById("demo").innerHTML = "EXPIRED";
        }
    }, 1000);
    </script>
</body>

</html>
